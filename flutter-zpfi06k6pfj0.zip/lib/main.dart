import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      darkTheme: ThemeData.dark(),
      theme: ThemeData.light(),
      home: const MyHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 102, 151, 46),
      appBar: AppBar(
        title: Center(child: const Text('Balkanize', style: TextStyle(color: Colors.white, fontFamily: "Schyler"),)),
        backgroundColor: Color.fromARGB(255, 37, 54, 46),
        // elevation: 0.00,
        
      ),
      drawer: Drawer(child: ListView(children: [
        const DrawerHeader(child: Center(child: Text( "Menu",style: TextStyle(color: Colors.white, fontSize: 20.00),)),
        decoration: BoxDecoration(color: Color.fromARGB(255, 47, 73, 48),
        ),),
        ListTile(title: Text("First Item", style: TextStyle(color: Color.fromARGB(255, 40, 70, 41)),),
        onTap: (() {
          Navigator.pop(context);
        }),
         leading: Icon(Icons.home, color: Color.fromARGB(255, 36, 65, 37),),
         trailing: Icon(Icons.more_vert_rounded, color: Colors.black,),
        ),
         ListTile(title: Text("Second Item",style: TextStyle(color: Color.fromARGB(255, 40, 70, 41)),),
        onTap: (() {
          Navigator.pop(context);
        }),
         leading: Icon(Icons.pool, color: Color.fromARGB(255, 55, 83, 56),),
         trailing: Icon(Icons.more_vert_rounded, color: Colors.black,)
        ),
        ListTile(title: Text("Third Item",style: TextStyle(color: Color.fromARGB(255, 40, 70, 41)),
        ),
        onTap: (() {
          Navigator.pop(context);
        }),
        leading: Icon(Icons.group, color: Color.fromARGB(255, 40, 70, 41),),
        trailing: Icon(Icons.more_vert_rounded, color: Colors.black,)
        ),
        ListTile(title: Text("Fourth Item",style: TextStyle(color: Color.fromARGB(255, 40, 70, 41)),),
        onTap: (() {
          Navigator.pop(context);
        }),
         leading: Icon(Icons.person_pin_circle, color: Color.fromARGB(255, 40, 70, 41),),
         trailing: Icon(Icons.more_vert_rounded, color: Colors.black,)
        ),
        ListTile(title: Text("Fifth Item",style: TextStyle(color: Color.fromARGB(255, 40, 70, 41)),),
        onTap: (() {
          Navigator.pop(context);
        }),
         leading: Icon(Icons.shield, color: Color.fromARGB(255, 40, 70, 41),),
         trailing: Icon(Icons.more_vert_rounded, color: Colors.black,)
        ),
        ListTile(title: Text("Sixth Item",style: TextStyle(color: Color.fromARGB(255, 40, 70, 41)),),
        onTap: (() {
          Navigator.pop(context);
        }),
         leading: Icon(Icons.account_box,color: Color.fromARGB(255, 40, 70, 41),),
         trailing: Icon(Icons.more_vert_rounded, color: Colors.black,)
        )
      ],)),
      body: Center(
        child: Container(
          height: 300,
          width: 200,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text('Teach me how to dance 🙌😉', style: TextStyle(color: Colors.white,),
                ),
                
                Text("Beware of loosing your Height 😎",  style: TextStyle(color: Colors.white, fontStyle: FontStyle.italic))
              ],
            ),
          padding: EdgeInsets.all(20.00),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),
          color: Color.fromARGB(255, 44, 85, 45), 
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          print('Rocking 👍');
        },
        backgroundColor: Colors.yellow[700],
        child: Icon(
          Icons.shower,
          color: Color.fromARGB(255, 42, 80, 62),
        ),
      ),
      bottomNavigationBar:BottomAppBar(color: Color.fromARGB(255, 37, 75, 38),
      child: Container(height: 50.0),
      shape: CircularNotchedRectangle(),
      notchMargin: 8,
      ), 
      floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
    );
  }
}

void main() {
  runApp(MyApp());
}
